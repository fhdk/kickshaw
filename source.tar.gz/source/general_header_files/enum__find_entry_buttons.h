#ifndef __enum__find_entry_row_buttons_h
#define __enum__find_entry_row_buttons_h

enum { CLOSE, BACK, FORWARD, NUMBER_OF_FIND_ENTRY_BUTTONS };

#endif
