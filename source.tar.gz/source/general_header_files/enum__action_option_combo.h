#ifndef __enum__action_option_combo_h
#define __enum__action_option_combo_h

enum { ACTION_OPTION_COMBO_ITEM, NUMBER_OF_ACTION_OPTION_COMBO_ELEMENTS };

#endif
