#ifndef __enum__execute_options_h
#define __enum__execute_options_h

enum { PROMPT, COMMAND, STARTUPNOTIFY, SN_OR_PROMPT = 2, NUMBER_OF_EXECUTE_OPTS };

#endif
