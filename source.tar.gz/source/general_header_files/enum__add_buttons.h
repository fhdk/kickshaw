#ifndef __enum__add_buttons_h
#define __enum__add_buttons_h

enum { MENU, PIPE_MENU, ITEM, SEPARATOR, ACTION_OR_OPTION, NUMBER_OF_ADD_BUTTONS };

#endif
