#ifndef __enum__move_row_h
#define __enum__move_row_h

enum { TOP, UP, DOWN, BOTTOM };

#endif