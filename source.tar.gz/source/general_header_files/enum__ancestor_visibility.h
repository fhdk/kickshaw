#ifndef __enum__ancestor_visibility_h
#define __enum__ancestor_visibility_h

enum { NONE_OR_VISIBLE_ANCESTOR, INVISIBLE_ANCESTOR, INVISIBLE_ORPHANED_ANCESTOR };

#endif
