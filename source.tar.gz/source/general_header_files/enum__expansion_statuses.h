#ifndef __enum__expansion_statuses_h
#define __enum__expansion_statuses_h

enum { AT_LEAST_ONE_IS_EXPANDED, AT_LEAST_ONE_IMD_CH_IS_EXP, AT_LEAST_ONE_IS_COLLAPSED, NUMBER_OF_EXPANSION_STATUSES };

#endif
