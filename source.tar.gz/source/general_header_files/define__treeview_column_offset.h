#ifndef __define__treeview_column_offset_h
#define __define__treeview_column_offset_h

#define TREEVIEW_COLUMN_OFFSET NUMBER_OF_TS_ELEMENTS - NUMBER_OF_COLUMNS

#endif
