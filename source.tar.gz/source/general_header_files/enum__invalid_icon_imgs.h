#ifndef __enum__invalid_icon_imgs_h
#define __enum__invalid_icon_imgs_h

enum { INVALID_PATH_ICON, INVALID_FILE_ICON, NUMBER_OF_INVALID_ICON_IMGS };

#endif
