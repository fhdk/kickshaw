#ifndef __enum__invalid_icon_imgs_status_h
#define __enum__invalid_icon_imgs_status_h

enum { NONE_OR_NORMAL, INVALID_PATH, INVALID_FILE };

#endif