#ifndef __enum__toolbar_buttons_h
#define __enum__toolbar_buttons_h

enum { TB_NEW, TB_OPEN, TB_SAVE, TB_SAVE_AS, TB_MOVE_UP, TB_MOVE_DOWN, TB_REMOVE, 
       TB_FIND, TB_EXPAND_ALL, TB_COLLAPSE_ALL, TB_QUIT, NUMBER_OF_TB_BUTTONS };

#endif