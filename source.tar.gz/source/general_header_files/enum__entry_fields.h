#ifndef __enum__entry_fields_h
#define __enum__entry_fields_h

enum { MENU_ELEMENT_OR_VALUE_ENTRY, ICON_PATH_ENTRY, MENU_ID_ENTRY, EXECUTE_ENTRY, NUMBER_OF_ENTRY_FIELDS };

#endif