#ifndef __enum__startupnotify_options_h
#define __enum__startupnotify_options_h

enum { ENABLED, NAME, WM_CLASS, ICON, NUMBER_OF_STARTUPNOTIFY_OPTS };

#endif
